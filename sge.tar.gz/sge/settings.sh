export SGE_ROOT=/usr/local/sge/sge_root
export SGE_QMASTER_PORT=536
export SGE_EXECD_PORT=537
export PATH=/usr/local/sge/bin:$PATH
